package ru.yandex.practicum.contacts.model;

public enum ContactType {
    TELEGRAM,
    WHATS_APP,
    VIBER,
    SIGNAL,
    THREEMA,
    PHONE,
    EMAIL
}
