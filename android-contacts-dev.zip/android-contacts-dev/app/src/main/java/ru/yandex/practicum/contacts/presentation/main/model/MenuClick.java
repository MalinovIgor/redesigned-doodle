package ru.yandex.practicum.contacts.presentation.main.model;

public enum MenuClick {
    SORT, FILTER, SEARCH
}
