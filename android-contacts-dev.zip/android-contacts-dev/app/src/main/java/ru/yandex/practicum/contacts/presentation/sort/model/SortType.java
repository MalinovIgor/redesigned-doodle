package ru.yandex.practicum.contacts.presentation.sort.model;

public enum SortType {
    BY_NAME,
    BY_NAME_REVERSED,
    BY_SURNAME,
    BY_SURNAME_REVERSED
}
