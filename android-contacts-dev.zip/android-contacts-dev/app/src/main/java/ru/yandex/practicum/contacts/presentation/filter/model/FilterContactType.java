package ru.yandex.practicum.contacts.presentation.filter.model;

public enum FilterContactType {
    ALL,
    TELEGRAM,
    WHATS_APP,
    VIBER,
    SIGNAL,
    THREEMA,
    PHONE,
    EMAIL
}
